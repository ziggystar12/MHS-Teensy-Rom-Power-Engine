# Firmware relinking SDK notices

This SDK contains compiled MHS application objects and the corresponding
sources of the libraries used to link them. Prism+ implementation source is
not included. Object files retain symbol and debug-location metadata needed
to reproduce the original linker layout; filenames and line numbers are
metadata, not embedded implementation source.

The new MHS Prism+ contributions identified in `PRISM-PLUS-COMPONENTS.json`
are subject to `LICENSE-PRISM-PLUS.txt`. Previously published MHS converter
and client infrastructure and original TeensyROM retain their MIT terms;
see `LICENSE-TEENSYROM-MHS-MIT.txt`. Existing license grants remain effective.
The `relink.mjs` build utility is MIT-licensed.

The firmware uses these libraries and their retained per-file notices:

| Component | Terms and notice location |
| --- | --- |
| Teensy4 core, PJRC and contributors | Per-file PJRC permissive, LGPL-2.1-or-later, BSD and Apache notices under `sources/hardware/cores/teensy4` |
| Arduino Stream, String, IPAddress, Time, EEPROM and related code | LGPL-2.1-or-later; `LICENSE-LGPL-2.1.txt` and original file headers |
| SPI and NativeW5100 compatibility header | Distributed using their explicit LGPL-2.1 alternative; original dual-license notices retained |
| SD / SdFat | MIT and retained component notices under `sources/hardware/libraries/SD` and `SdFat` |
| USBHost_t36 | Retained per-file MIT/PJRC notices under `sources/hardware/libraries/USBHost_t36` |
| NativeEthernet | MIT, with the separately noted dual-licensed compatibility header |
| FNET and included support code | Apache-2.0 and retained component notices under `sources/hardware/libraries/FNET`; `LICENSE-APACHE-2.0.txt` |
| CRC32 by Christopher Baker and contributors | MIT; `sources/user-libraries/CRC32/LICENSE.md` |
| PN532 by Adafruit Industries and Seeed Technology | BSD; `LICENSE-PN532-BSD.txt` |
| FlasherX contributors | Public-domain notice retained in `NOTICE-FLASHERX.txt`; underlying Teensy routines retain their notices |
| Original Prism display components | MIT, copyright Patai Gergely; `LICENSE-DISPLAY-COMPONENTS.txt` |

Some complete vendor source directories contain optional GPL-covered
examples or DigitalIO implementations that are not compiled into this
firmware. They retain their own notices and the supplied GPL license texts.
Their presence as separately supplied source does not change the licensing
of the new MHS Prism+ components. The compiled-dependency audit records
which GNU-covered files actually participate in this build.

LGPL-covered library sources remain modifiable and redistributable under
their licenses. The supplied objects and build recipes allow replacing
those libraries and relinking. The Prism+ license preserves modification
of the combined work for the customer's own use and reverse engineering
for debugging those modifications, as required by the applicable LGPL.

The SDK contains a patched Teensy `yield.cpp` with the existing MPE
`USB_DISABLED` guard. `profiles/minimal/bootdata.c` and
`profiles/gui/bootdata.c`, and their linker scripts, carry the image layout
used by this firmware. These changes are supplied in source form.

This firmware SDK contains no NES, DOOM or commercial game engine/data.
Firmware-embedded TeensyROM utilities retain their existing source notices
and provenance. Game/demo licenses supplied with VM packages remain separate.
