// SPDX-License-Identifier: MIT
// Relink the supplied application objects with the supplied or rebuilt libraries.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const sdk=import.meta.dirname;
const option=(name,fallback)=>{const i=process.argv.indexOf(name);return i<0?fallback:process.argv[i+1];};
const toolchain=path.resolve(option('--toolchain',process.env.ARM_TOOLCHAIN??''));
assert(option('--toolchain',process.env.ARM_TOOLCHAIN),'Pass --toolchain PATH to the Teensy GNU Arm 11.3.1 arm directory');
const output=path.resolve(option('--output',path.join(sdk,'output')));
const rebuild=process.argv.includes('--rebuild-libraries');
const verify=process.argv.includes('--verify-original');
const manifest=JSON.parse(fs.readFileSync(path.join(sdk,'manifest.json')));
const suffix=process.platform==='win32'?'.exe':'';
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const expand=s=>s.replaceAll('${SDK}',sdk).replaceAll('${TOOLCHAIN}',toolchain).replaceAll('${OUTPUT}',output);
function run(name,args){
  const exe=path.join(toolchain,'bin',name.replace(/\.exe$/,'')+suffix);
  if(args.join(' ').length>16000){
    fs.mkdirSync(output,{recursive:true});const response=path.join(output,'tool-arguments.rsp');
    fs.writeFileSync(response,args.map(a=>'"'+a.replaceAll('\\','/').replaceAll('"','\\"')+'"').join('\n')+'\n');args=['@'+response];
  }
  const r=spawnSync(exe,args,{cwd:sdk,encoding:'utf8',maxBuffer:16*1024*1024,env:{...process.env,SOURCE_DATE_EPOCH:'1788480000'}});
  assert.equal(r.status,0,exe+'\n'+r.error+'\n'+r.stdout+'\n'+r.stderr);
  return r.stdout;
}
const compilerVersion=run('arm-none-eabi-gcc',['-dumpfullversion']).trim();
assert.equal(compilerVersion,'11.3.1','This SDK requires its recorded GNU Arm compiler version');
const cpu=['-mthumb','-mcpu=cortex-m7','-mfloat-abi=hard','-mfpu=fpv5-d16'];
const imageRecords=[];
for(const [profile,config] of Object.entries(manifest.profiles)){
  const dir=path.join(output,profile);fs.mkdirSync(dir,{recursive:true});
  for(const rel of [...config.objects,'core/core.a']){
    const dest=path.join(dir,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});
    fs.copyFileSync(path.join(sdk,'objects',profile,rel),dest);
  }
  if(rebuild){
    console.log('Rebuilding '+profile+' libraries ('+config.recipes.length+' source files)');
    for(const recipe of config.recipes){
      fs.mkdirSync(path.dirname(path.join(dir,recipe.object)),{recursive:true});
      run(recipe.compiler,recipe.arguments.map(expand));
    }
    const archive=path.join(dir,'core/core.a');fs.unlinkSync(archive);
    run('arm-none-eabi-gcc-ar',['rcs',archive,...config.coreMembers.map(member=>path.join(dir,'core',member))]);
  }
  const elf=path.join(dir,config.name+'.ino.elf'),hex=path.join(dir,config.name+'.ino.hex');
  run('arm-none-eabi-gcc',['-O2','-Wl,--gc-sections,--relax','-T'+path.join(sdk,'profiles',profile,'link.ld'),...cpu,'-o',elf,...config.objects.map(rel=>path.join(dir,rel)),path.join(dir,'core/core.a'),'-L'+dir,'-larm_cortexM7lfsp_math','-lm','-lstdc++']);
  run('arm-none-eabi-objcopy',['-O','ihex','-R','.eeprom',elf,hex]);
  const data=fs.readFileSync(hex),sha256=hash(data);
  if(verify)assert.equal(sha256,config.originalHexSha256,profile+' relink does not match release image');
  imageRecords.push({profile,path:hex,sha256});
  console.log(profile+' HEX '+sha256);
}
const merged=new Map();
for(const image of imageRecords){
  let base=0,eof=false;
  const lo=image.profile==='minimal'?0x60000000:0x60060000,hi=image.profile==='minimal'?0x60060000:0x607c0000;
  for(const line of fs.readFileSync(image.path,'utf8').trim().split(/\r?\n/)){
    assert(!eof&&/^:[0-9A-F]+$/i.test(line),'Invalid HEX syntax or data after EOF');
    const b=Buffer.from(line.slice(1),'hex');assert.equal(b.length,b[0]+5);assert.equal(b.reduce((a,v)=>a+v,0)&255,0);
    if(b[3]===4){assert.equal(b[0],2);base=b.readUInt16BE(4)*65536;}
    else if(b[3]===0)for(let i=0;i<b[0];i++){const a=base+b.readUInt16BE(1)+i;assert(a>=lo&&a<hi&&!merged.has(a),'Image partition overlap/bounds');merged.set(a,b[i+4]);}
    else if(b[3]===1)eof=true;else assert([3,5].includes(b[3]),'Unsupported HEX record');
  }
  assert(eof,'Missing HEX EOF');
}
const record=(addr,type,data)=>{const b=Buffer.alloc(data.length+5);b[0]=data.length;b.writeUInt16BE(addr,1);b[3]=type;data.copy(b,4);b[b.length-1]=(-b.reduce((a,v)=>a+v,0))&255;return ':'+b.toString('hex').toUpperCase();};
const addresses=[...merged.keys()].sort((a,b)=>a-b);let high=-1,lines=[];
for(let i=0;i<addresses.length;){const start=addresses[i];if(Math.floor(start/65536)!==high){high=Math.floor(start/65536);const h=Buffer.alloc(2);h.writeUInt16BE(high);lines.push(record(0,4,h));}const data=[];while(i<addresses.length&&addresses[i]===start+data.length&&Math.floor(addresses[i]/65536)===high&&data.length<16)data.push(merged.get(addresses[i++]));lines.push(record(start&65535,0,Buffer.from(data)));}
lines.push(':00000001FF');
const firmware=Buffer.from(lines.join('\n')+'\n'),sha256=hash(firmware);
if(verify)assert.equal(sha256,manifest.firmwareSha256,'Combined firmware differs from release');
const destination=path.join(output,'MPE_Firmware-V'+manifest.version+(verify?'':'-relinked')+'.hex');
fs.writeFileSync(destination,firmware);
fs.writeFileSync(path.join(output,'verification.json'),JSON.stringify({passed:true,rebuildLibraries:rebuild,verifyOriginal:verify,compilerVersion,firmware:destination,sha256,images:imageRecords},null,2)+'\n');
console.log('Firmware '+sha256+' '+destination);
