# MPE firmware 1.2.23 relinking SDK

This package lets you replace the firmware's libraries and relink its two
Teensy images while keeping the original MHS application and Prism+ objects.
It supplies all recorded library compilation inputs and recipes, both
application object sets, both core archives, linker scripts, boot headers,
license notices and the firmware HEX combiner. It does not contain the
private Prism+ implementation source or a graphical development environment.

Use Node.js 24 and the GNU Arm 11.3.1 compiler distributed with Teensyduino
1.61.0. An existing installation can be used. With Arduino CLI, the pinned
Teensy core can be installed using:

```powershell
arduino-cli core update-index --additional-urls https://www.pjrc.com/teensy/package_teensy_index.json
arduino-cli core install teensy:avr@1.61.0 --additional-urls https://www.pjrc.com/teensy/package_teensy_index.json
```

Pass the compiler's `arm` directory, containing `bin/arm-none-eabi-gcc`, to
the script. On a usual Windows Arduino installation it is below
`%LOCALAPPDATA%/Arduino15/packages/teensy/tools/teensy-compile/11.3.1/arm`.

From this extracted SDK directory, reproduce the official HEX using the
supplied objects:

```powershell
node relink.mjs --toolchain C:/path/to/teensy-compile/11.3.1/arm --verify-original
```

Rebuild every recorded library source before relinking:

```powershell
node relink.mjs --toolchain C:/path/to/teensy-compile/11.3.1/arm --rebuild-libraries --verify-original
```

Both unmodified routes must reproduce the firmware SHA-256 in `manifest.json`.
To experiment with a modified library, edit its sources, run the second
command without `--verify-original`, and inspect the generated
`output/verification.json`. The script writes a `-relinked.hex` filename so
an experimental output is distinct from the official firmware. You can
select another destination with `--output PATH`.

Only this SDK's output directory is written by the relinking utility. It
does not modify your installed compiler or upload firmware to a device.
The script retains image-partition and linked-memory assertions when you
rebuild. Reproducing or modifying firmware is separate from flashing and
physical hardware validation.

Read `NOTICES.md`, `LICENSE-PRISM-PLUS.txt` and the supplied third-party
licenses for the component-specific permissions. The old generic MHS color
converter and original Prism retain their MIT grants. The new Prism+
contributions have the separate, prospective MHS license with the explicit
LGPL exceptions. The public NES engine source is distributed separately
with NESVM; no engine source is required for this firmware relink.
