# DoomVM 1.2

Install MPE firmware 1.2.5, then extract this complete ZIP onto the SD
root, replacing matching files. Keep your existing music files. Open DOOMVM.crt.
One launcher supports PAL and NTSC C64s with TeensyROM+ v0.4.

F1 uses MHS colour fitting with steady shading and a solid-colour status bar.
Hold Commodore + Control and press F1, F3, F5 or F7 to select a display mode.
F7 Sharp is unchanged. Earlier firmware uses its existing F1 converter.

W/S or Up/Down: move. Left/Right: turn. A/D: strafe. Control or port-2
joystick fire: shoot. Space: use. Return: run/accept. Tab: map. Escape: menu.
M: music on/off. Reset: return to the desktop.

The level route is E1M1, E1M4, E1M5 and E1M8. Oversized maps are skipped.
Saving is not supported. Shareware game data and the existing fault-tolerant
launcher are included. Optional doom-e1m1-pal.s3m and doom-e1m1-ntsc.s3m
music files remain compatible; they are not bundled.

The new colour profile passes software tests; physical testing is still needed.
See VMS/DOOMVM/NOTICES.md for engine and game-data credits and licences.
Source and downloads: https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine
