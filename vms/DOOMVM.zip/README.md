# DoomVM 1.2.1

Install MPE GUI firmware 1.2.23, then extract this complete ZIP onto the SD
root, replacing matching files. Keep your existing music files. Open DOOMVM.crt.
One launcher supports PAL and NTSC C64s with TeensyROM+ v0.4.

Version 1.2.1 lets the engine find optional music inside self-contained .MPE
cartridges and uses an equivalent CRC lookup that fits the existing code budget.
The ordinary SD-folder launch, four-level route, controls and picture are unchanged.
The package contains the same tested status-recovery launcher as the previous ZIP.

F1 uses MHS colour fitting with steady shading and a solid-colour status bar.
Hold Commodore + Control and press F1, F3, F5 or F7 to select a display mode.
F7 Sharp is unchanged. Earlier firmware uses its existing F1 converter.
MHS Prism and Prism+ do not apply to DoomVM; it uses its own display modes.

W/S or Up/Down: move. Left/Right: turn. A/D: strafe. Control or port-2
joystick fire: shoot. Space: use. Return: run/accept. Tab: map. Escape: menu.
M: music on/off. Reset: return to the desktop.

The level route is E1M1, E1M4, E1M5 and E1M8. Oversized maps are skipped.
Saving is not supported. Shareware game data is included. Optional
doom-e1m1-pal.s3m and doom-e1m1-ntsc.s3m remain compatible and are not bundled.

Engine linking, source rebuild, native tests and PAL/NTSC C64 startup in VICE
passed. Physical gameplay and custom-bus timing remain unverified for this release.
See VMS/DOOMVM/NOTICES.md for engine and game-data credits and licences.
Source and downloads: https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine
