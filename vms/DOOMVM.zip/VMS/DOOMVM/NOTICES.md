# DoomVM notices

The engine is based on [GBADoom](https://github.com/doomhack/GBADoom), a
GPL-2.0-or-later derivative of PrBoom, at commit
`89097b3ff31ac1e1b2cdce9854e49726cfa462bf`. MHS changes dated September 5, 2026
add the Teensy module interface, resource cache, C64 video, HUD, SID audio
and shareware progression with memory-based map skipping.
The September 14, 2026 patch adds optional music lookup in self-contained
cartridges and an equivalent table-based CRC calculation.
Original copyright notices remain in the corresponding source.

`COPYING.GPL-2.0` contains the engine licence. Complete corresponding source,
headers, linker script and rebuild tools are available separately in
[Source/DoomEngine](https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine/tree/main/Source/DoomEngine).
The [build instructions](https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine/blob/main/docs/BUILDING.md)
explain how to rebuild and install a modified engine. Host interfaces and tools
retain their own licence notices.

The C64 client source and launcher builder are in `Source/VM/client/` and
`scripts/build-doom-client.mjs` in the
[MHS Power Engine repository](https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine).

## Included shareware game data

`doom1.gbd` contains the Doom shareware 1.9 game data converted for DoomVM.
Doom and the original game resources are copyright id Software.
The game data is separate from the GPL engine code; MHS does not claim
ownership of those resources or relicense them under the GPL.

`DOOM-SHAREWARE-LICENSE.txt` reproduces the original shareware licence and
historical redistribution clarification preserved in
[Debian's Doom shareware package](https://sources.debian.org/src/doom-wad-shareware/1.9.fixed-2/debian/copyright/).

Optional music is not included. Its credits and terms remain with its source.
