Place your own .gb, .gbc and .gc ROMs here. No games included.
Direct .gc launch from a firmware browser requires the updated ROM-routing firmware.
