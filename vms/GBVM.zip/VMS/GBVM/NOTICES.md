GBVM incorporates gnuboy by Laguna and Gilgamesh through Jean-Marc Harvengt's
MCUME Teensy port, under GNU GPL v2 or later. See LICENSE-gnuboy.txt.
Complete corresponding sources and rebuild tools accompany
[Travis's developer handoff](https://github.com/ziggystar12/TeensyROM/tree/codex/mpe-prism-plus-update/mpe/review/console-sources)
as `GBVM-1.2.24-source.zip`. This download contains only the runtime.
Menu font by Daniel Hepper is public domain; original notices are retained.
Nintendo/Game Boy names identify compatible formats; no endorsement implied.
Use your own lawful game media. No commercial test ROM is included.
