GBVM incorporates gnuboy by Laguna and Gilgamesh through Jean-Marc Harvengt's
MCUME Teensy port, under GNU GPL v2 or later. See LICENSE-gnuboy.txt.
Source and rebuild tools are maintained in the firmware repository under
engine/gnuboy, vm/gb and scripts/build-gb-core.mjs, outside the SD package.
Menu font by Daniel Hepper is public domain; original notices are retained.
Nintendo/Game Boy names identify compatible formats; no endorsement implied.
Use your own lawful game media. Neither supplied private test ROM is included.
