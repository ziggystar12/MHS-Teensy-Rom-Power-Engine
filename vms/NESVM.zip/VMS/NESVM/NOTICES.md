# NESVM source and third-party notices

Corresponding engine source and rebuild instructions:
https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine/tree/main/Source/NESEngine
C64 launcher source and rebuild instructions:
https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine/tree/main/Source/NESClient
Build record: https://github.com/ziggystar12/MHS-Teensy-Rom-Power-Engine/blob/main/docs/NESVM-build.json

The active NESVM CPU/PPU are Nofrendo, copyright (c) 1998-2000 Matthew Conte,
ported from Jean-Marc Harvengt's MCUME Teensy41 version at commit
27f6b906aca34e06d6647bdca8215e25f8d20aa5. Nofrendo and the MPE core adapter
are distributed under version 2 of the GNU Library General Public License.
See LICENSE-Nofrendo.txt. Complete corresponding module source and rebuild
instructions are provided at the public Source/NESEngine location above;
the source revision and binary hashes are recorded in docs/NESVM-build.json. This is a modified MPE port, not
an unmodified MCUME release; it retains MPE input, SID and indexed video.

The source/reference core retains Andre Weissflog's m6502 from chips, under
the zlib/libpng license; it is not the linked runtime CPU in this package.
Copyright (c) 2018 Andre Weissflog.

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not claim
   that you wrote the original software. If you use this software in a product,
   an acknowledgment in the product documentation would be appreciated but is
   not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.

The font8x8_basic font by Daniel Hepper, derived from Marcel Sondaar/IBM fonts,
is public domain. Crossbow is the authorized repository demo; it is not placed
under the engine's software license. SMB and other private ROMs are not bundled.

## C64 client and shared-code MIT notice

MIT License

Copyright (c) 2023 Travis Smith

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
