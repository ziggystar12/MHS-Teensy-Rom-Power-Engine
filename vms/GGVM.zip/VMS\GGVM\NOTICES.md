# GGVM notices

TotalSMS Copyright (c) 2021 ITotalJustice, MIT.
Scheduler Copyright (c) 2024 TotalJustice, MIT.
See LICENSE-TotalSMS.txt and LICENSE-scheduler.txt.

The GGVM module adapter is derived from the MHS GBVM adapter and is provided
under GNU GPL version 2 or later, without warranty. See LICENSE-GPL-2.0.txt.
The portable core additions and cache/save helpers carry their own MIT notices.
The shared C64 receiver and build tools retain their repository notices.

Complete source, upstream provenance, build tools and reproducible source
snapshot remain in the accompanying private development repository/output,
separate from this runtime ZIP. Provide corresponding source to recipients
with the module under the applicable license terms.

No Sega BIOS or commercial game ROMs are included. Game names identify local
compatibility checks only; Sega and Sonic are their respective owners' marks.
